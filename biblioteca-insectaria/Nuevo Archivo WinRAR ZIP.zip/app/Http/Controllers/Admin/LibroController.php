<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Libro;
use App\Models\Mueble;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class LibroController extends Controller
{
    public function index(Request $request): View
    {
        $q = trim($request->string('q')->toString());
        $libros = Libro::query()
            ->with('mueble:id,nombre')
            ->withCount('ejemplares')
            ->withCount(['ejemplares as disponibles_count' => fn ($query) => $query->where('estado', 'disponible')])
            ->when($q !== '', fn ($query) => $query->where(fn ($search) => $search
                ->where('titulo', 'like', "%{$q}%")
                ->orWhere('autor', 'like', "%{$q}%")
                ->orWhereHas('ejemplares', fn ($items) => $items->where('codigo_barras', 'like', "%{$q}%")))
            )->orderBy('titulo')->paginate(25)->withQueryString();

        return view('admin.libros.index', compact('libros', 'q'));
    }

    public function create(): View
    {
        return view('admin.libros.form', ['libro' => new Libro, 'muebles' => Mueble::orderBy('nombre')->get()]);
    }

    public function store(Request $request): RedirectResponse
    {
        $libro = Libro::create($this->validated($request));

        return redirect()->route('admin.libros.show', $libro)->with('status', 'Libro creado correctamente.');
    }

    public function show(Libro $libro): View
    {
        $libro->load('mueble')->loadCount('ejemplares')
            ->loadCount(['ejemplares as disponibles_count' => fn ($query) => $query->where('estado', 'disponible')]);

        return view('admin.libros.show', compact('libro'));
    }

    public function edit(Libro $libro): View
    {
        return view('admin.libros.form', ['libro' => $libro, 'muebles' => Mueble::orderBy('nombre')->get()]);
    }

    public function update(Request $request, Libro $libro): RedirectResponse
    {
        $libro->update($this->validated($request));

        return redirect()->route('admin.libros.show', $libro)->with('status', 'Libro actualizado correctamente.');
    }

    public function destroy(Libro $libro): RedirectResponse
    {
        if ($libro->ejemplares()->where(function ($query) {
            $query->where('estado', 'prestado')
                ->orWhereHas('prestamos', fn ($prestamos) => $prestamos->where('estado', 'activo'));
        })->exists()) {
            return back()->withErrors(['libro' => 'No se puede dar de baja: el libro tiene ejemplares prestados. Registra primero la devolución.']);
        }

        if ($libro->ejemplares()->whereHas('prestamos')->exists()) {
            $libro->ejemplares()->update(['estado' => 'baja']);
        } else {
            $libro->ejemplares()->delete();
        }

        $libro->delete();

        return redirect()->route('admin.libros.index')->with('status', 'Libro dado de baja correctamente.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'titulo' => ['required', 'string', 'max:255'],
            'autor' => ['required', 'string', 'max:255'],
            'isbn' => ['nullable', 'string', 'max:20'],
            'editorial' => ['nullable', 'string', 'max:255'],
            'anio' => ['nullable', 'integer', 'between:1000,9999'],
            'portada_url' => ['nullable', 'url', 'max:255'],
            'mueble_id' => ['nullable', 'exists:muebles,id'],
        ], [
            'titulo.required' => 'El título es obligatorio.',
            'autor.required' => 'El autor es obligatorio.',
            'portada_url.url' => 'La portada debe ser una dirección web válida.',
        ]);
    }
}
