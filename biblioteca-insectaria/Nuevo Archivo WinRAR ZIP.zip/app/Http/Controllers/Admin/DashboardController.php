<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Prestamo;
use App\Models\Socio;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(): View
    {
        $monthExpression = DB::connection()->getDriverName() === 'sqlite'
            ? "strftime('%Y-%m', fecha_prestamo)"
            : "DATE_FORMAT(fecha_prestamo, '%Y-%m')";
        $meses = Prestamo::query()
            ->selectRaw("{$monthExpression} as mes, COUNT(*) as total")
            ->where('fecha_prestamo', '>=', now()->subMonths(11)->startOfMonth())
            ->groupBy('mes')
            ->orderBy('mes')
            ->get();

        $librosMasPrestados = DB::table('prestamos')
            ->join('ejemplares', 'prestamos.ejemplar_id', '=', 'ejemplares.id')
            ->join('libros', 'ejemplares.libro_id', '=', 'libros.id')
            ->select('libros.titulo', DB::raw('COUNT(*) as total'))
            ->groupBy('libros.id', 'libros.titulo')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        return view('admin.dashboard', [
            'prestamosMes' => $meses,
            'librosMasPrestados' => $librosMasPrestados,
            'sociosActivos' => Socio::query()->where('activo', true)->whereDate('vigente_hasta', '>=', today())->count(),
            'prestamosActivos' => Prestamo::query()->where('estado', 'activo')->count(),
            'comunas' => Socio::query()->select('comuna', DB::raw('COUNT(*) as total'))->groupBy('comuna')->orderByDesc('total')->limit(8)->get(),
            'ocupaciones' => Socio::query()->select('ocupacion', DB::raw('COUNT(*) as total'))->whereNotNull('ocupacion')->groupBy('ocupacion')->orderByDesc('total')->limit(8)->get(),
            'morosos' => Prestamo::query()->where('estado', 'activo')->whereDate('fecha_vencimiento', '<', today())->count(),
        ]);
    }
}
