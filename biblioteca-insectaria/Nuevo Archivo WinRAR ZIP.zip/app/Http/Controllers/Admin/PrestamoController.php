<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Prestamo;
use App\Models\Socio;
use App\Services\PrestamoService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\View\View;

class PrestamoController extends Controller
{
    public function index(): View
    {
        $prestamos = Prestamo::query()->with(['socio', 'ejemplar.libro', 'registradoPor'])
            ->where('estado', 'activo')->orderBy('fecha_vencimiento')->paginate(25);
        $socios = Socio::query()->where('activo', true)->orderBy('apellidos')->orderBy('nombres')->get();
        $contactar = Prestamo::query()->with(['socio', 'ejemplar.libro'])
            ->where('estado', 'activo')
            ->whereDate('fecha_vencimiento', today()->addDays((int) config('biblioteca.dias_recordatorio')))
            ->whereHas('socio', fn ($query) => $query->whereNull('email')->orWhere('email', ''))
            ->get();

        return view('admin.prestamos.index', ['prestamos' => $prestamos, 'socios' => $socios, 'contactar' => $contactar, 'operacionUuid' => (string) Str::uuid()]);
    }

    public function store(Request $request, PrestamoService $service): RedirectResponse|JsonResponse
    {
        $datos = $request->validate([
            'codigo_barras' => ['required', 'string', 'max:50'],
            'socio_id' => ['required', 'integer', 'exists:socios,id'],
            'operacion_uuid' => ['required', 'uuid'],
        ]);

        $prestamo = $service->prestar($datos['codigo_barras'], (int) $datos['socio_id'], $request->user(), $datos['operacion_uuid']);

        if ($request->expectsJson()) {
            return response()->json([
                'mensaje' => 'Préstamo registrado correctamente.',
                'redireccion' => route('admin.prestamos.index'),
            ]);
        }

        return redirect()->route('admin.prestamos.index')->with('status', "Préstamo registrado. Vence el {$prestamo->fecha_vencimiento->format('d/m/Y')}.");
    }

    public function devolver(Request $request, PrestamoService $service): RedirectResponse|JsonResponse
    {
        $datos = $request->validate(['codigo_barras' => ['required', 'string', 'max:50']]);
        $resultado = $service->devolver($datos['codigo_barras'], $request->user());

        if (! $resultado['devuelto']) {
            if ($request->expectsJson()) {
                return response()->json(['mensaje' => 'Este ejemplar no tiene un préstamo activo.'], 422);
            }

            return back()->withErrors(['codigo_barras' => 'Este ejemplar no tiene un préstamo activo.']);
        }

        $mensaje = $resultado['dias_atraso'] > 0
            ? "Devolución registrada. El libro tenía {$resultado['dias_atraso']} días de atraso."
            : 'Devolución registrada. El ejemplar está disponible.';

        if ($request->expectsJson()) {
            return response()->json(['mensaje' => $mensaje, 'redireccion' => route('admin.prestamos.index')]);
        }

        return redirect()->route('admin.prestamos.index')->with('status', $mensaje);
    }

    public function morosidad(): View
    {
        $prestamos = Prestamo::query()
            ->with(['socio', 'ejemplar.libro'])
            ->where('estado', 'activo')
            ->whereDate('fecha_vencimiento', '<', today())
            ->orderBy('fecha_vencimiento')
            ->paginate(25);

        return view('admin.prestamos.morosidad', compact('prestamos'));
    }
}
