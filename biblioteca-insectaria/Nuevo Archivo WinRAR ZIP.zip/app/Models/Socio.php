<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Socio extends Model
{
    protected $fillable = [
        'run', 'nombres', 'apellidos', 'telefono', 'email', 'comuna',
        'ocupacion', 'fecha_inscripcion', 'vigente_hasta', 'activo',
    ];

    protected function casts(): array
    {
        return [
            'fecha_inscripcion' => 'date',
            'vigente_hasta' => 'date',
            'activo' => 'boolean',
        ];
    }

    public function prestamos(): HasMany
    {
        return $this->hasMany(Prestamo::class);
    }

    public function prestamosActivos(): HasMany
    {
        return $this->prestamos()->where('estado', 'activo');
    }
}
