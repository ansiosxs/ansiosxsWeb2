<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Libro extends Model
{
    use SoftDeletes;

    protected $fillable = ['titulo', 'autor', 'isbn', 'editorial', 'anio', 'portada_url', 'mueble_id'];

    public function ejemplares(): HasMany
    {
        return $this->hasMany(Ejemplar::class);
    }

    public function mueble(): BelongsTo
    {
        return $this->belongsTo(Mueble::class);
    }
}
