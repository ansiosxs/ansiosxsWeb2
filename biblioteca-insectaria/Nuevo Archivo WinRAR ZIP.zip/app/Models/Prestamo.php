<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Prestamo extends Model
{
    protected $fillable = [
        'socio_id', 'ejemplar_id', 'user_id', 'fecha_prestamo', 'fecha_vencimiento',
        'fecha_devolucion', 'devuelto_por_user_id', 'estado', 'ejemplar_activo_id', 'operacion_uuid',
    ];

    protected function casts(): array
    {
        return [
            'fecha_prestamo' => 'datetime',
            'fecha_vencimiento' => 'date',
            'fecha_devolucion' => 'datetime',
        ];
    }

    public function socio(): BelongsTo
    {
        return $this->belongsTo(Socio::class);
    }

    public function ejemplar(): BelongsTo
    {
        return $this->belongsTo(Ejemplar::class);
    }

    public function registradoPor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function devueltoPor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'devuelto_por_user_id');
    }

    public function recordatorio(): HasOne
    {
        return $this->hasOne(Recordatorio::class);
    }
}
