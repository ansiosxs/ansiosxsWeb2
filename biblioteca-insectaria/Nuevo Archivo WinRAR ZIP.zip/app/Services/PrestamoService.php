<?php

namespace App\Services;

use App\Models\Ejemplar;
use App\Models\Prestamo;
use App\Models\Socio;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PrestamoService
{
    public function prestar(string $codigoBarras, int $socioId, User $voluntario, string $operacionUuid): Prestamo
    {
        try {
            return DB::transaction(function () use ($codigoBarras, $socioId, $voluntario, $operacionUuid) {
                $ejemplar = Ejemplar::query()
                    ->where('codigo_barras', $codigoBarras)
                    ->lockForUpdate()
                    ->first();

                if (! $ejemplar) {
                    throw ValidationException::withMessages(['codigo_barras' => 'No se encontró un ejemplar con ese código.']);
                }

                $existente = Prestamo::query()->where('operacion_uuid', $operacionUuid)->lockForUpdate()->first();

                if ($existente) {
                    return $existente;
                }

                $socio = Socio::query()->lockForUpdate()->find($socioId);

                if (! $socio || ! $socio->activo) {
                    throw ValidationException::withMessages(['socio_id' => 'El socio no está activo.']);
                }

                if ($ejemplar->estado !== 'disponible') {
                    throw ValidationException::withMessages(['codigo_barras' => 'El ejemplar no está disponible para préstamo.']);
                }

                if ($socio->vigente_hasta->lt(today())) {
                    throw ValidationException::withMessages(['socio_id' => 'La membresía está vencida. Renueva antes de prestar libros.']);
                }

                if ($socio->prestamosActivos()->whereDate('fecha_vencimiento', '<', today())->exists()) {
                    throw ValidationException::withMessages(['socio_id' => 'El socio tiene préstamos vencidos y debe devolverlos antes de retirar otro libro.']);
                }

                $limite = (int) config('biblioteca.max_prestamos_activos');

                if ($socio->prestamosActivos()->count() >= $limite) {
                    throw ValidationException::withMessages(['socio_id' => "El socio ya alcanzó el máximo de {$limite} préstamos activos."]);
                }

                $ahora = now();
                $prestamo = Prestamo::query()->create([
                    'socio_id' => $socio->id,
                    'ejemplar_id' => $ejemplar->id,
                    'user_id' => $voluntario->id,
                    'fecha_prestamo' => $ahora,
                    'fecha_vencimiento' => $ahora->copy()->addDays((int) config('biblioteca.plazo_prestamo_dias'))->toDateString(),
                    'estado' => 'activo',
                    'ejemplar_activo_id' => $ejemplar->id,
                    'operacion_uuid' => $operacionUuid,
                ]);

                $ejemplar->update(['estado' => 'prestado']);

                return $prestamo;
            }, 3);
        } catch (QueryException $exception) {
            if (in_array($exception->getCode(), ['23000', '23505'], true)) {
                $existente = Prestamo::query()->where('operacion_uuid', $operacionUuid)->first();

                if ($existente) {
                    return $existente;
                }
            }

            throw $exception;
        }
    }

    public function devolver(string $codigoBarras, User $voluntario): array
    {
        return DB::transaction(function () use ($codigoBarras, $voluntario) {
            $ejemplar = Ejemplar::query()
                ->where('codigo_barras', $codigoBarras)
                ->lockForUpdate()
                ->first();

            if (! $ejemplar) {
                throw ValidationException::withMessages(['codigo_barras' => 'No se encontró un ejemplar con ese código.']);
            }

            $prestamo = Prestamo::query()
                ->where('ejemplar_id', $ejemplar->id)
                ->where('estado', 'activo')
                ->lockForUpdate()
                ->first();

            if (! $prestamo) {
                return ['devuelto' => false, 'dias_atraso' => 0];
            }

            $hoy = today();
            $diasAtraso = max(0, (int) $prestamo->fecha_vencimiento->diffInDays($hoy, false));

            $prestamo->update([
                'estado' => 'devuelto',
                'fecha_devolucion' => now(),
                'devuelto_por_user_id' => $voluntario->id,
                'ejemplar_activo_id' => null,
            ]);

            $ejemplar->update(['estado' => 'disponible']);

            return ['devuelto' => true, 'dias_atraso' => $diasAtraso];
        }, 3);
    }
}
