<?php

namespace App\Console\Commands;

use App\Models\Ejemplar;
use App\Models\Libro;
use App\Models\Mueble;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ImportarCatalogo extends Command
{
    protected $signature = 'biblioteca:importar-catalogo {archivo : CSV exportado desde Excel} {--reporte=storage/app/importacion-informe.csv : Ruta del informe de filas rechazadas}';

    protected $description = 'Importa libros y ejemplares desde un CSV exportado desde Excel y genera un informe de filas rechazadas.';

    public function handle(): int
    {
        $path = $this->argument('archivo');

        if (! is_file($path) || ! is_readable($path)) {
            $this->error('No se puede leer el archivo CSV indicado.');

            return self::FAILURE;
        }

        $file = new \SplFileObject($path, 'r');
        $firstLine = $file->fgets();
        $delimiter = substr_count($firstLine, ';') > substr_count($firstLine, ',') ? ';' : ',';
        $file->rewind();
        $headers = $file->fgetcsv($delimiter);

        if (! is_array($headers)) {
            $this->error('El archivo no contiene una fila de encabezados.');

            return self::FAILURE;
        }

        $headers = array_map(fn ($header) => mb_strtolower(trim((string) $header)), $headers);
        $headers[0] = preg_replace('/^\xEF\xBB\xBF/', '', $headers[0]);
        $required = ['titulo', 'autor'];

        if (array_diff($required, $headers)) {
            $this->error('El CSV debe incluir las columnas titulo y autor.');

            return self::FAILURE;
        }

        $reportPath = $this->option('reporte');
        $directory = dirname($reportPath);
        if (! is_dir($directory) && ! mkdir($directory, 0755, true) && ! is_dir($directory)) {
            $this->error('No se pudo crear la carpeta del informe.');

            return self::FAILURE;
        }

        $report = fopen($reportPath, 'wb');
        if ($report === false) {
            $this->error('No se pudo crear el informe de importación.');

            return self::FAILURE;
        }
        if (fputcsv($report, ['fila', 'motivo']) === false) {
            fclose($report);
            $this->error('No se pudo escribir el encabezado del informe.');

            return self::FAILURE;
        }
        $rejected = 0;
        $line = 1;
        $imported = 0;

        while (! $file->eof()) {
            $values = $file->fgetcsv($delimiter);
            $line++;

            if (! is_array($values) || count($values) === 1 && ($values[0] === null || trim((string) $values[0]) === '')) {
                continue;
            }

            $row = array_combine($headers, array_pad(array_slice($values, 0, count($headers)), count($headers), null));
            $row = array_map(fn ($value) => is_string($value) ? trim($value) : $value, $row);
            $errors = Validator::make($row, [
                'titulo' => ['required', 'string', 'max:255'],
                'autor' => ['required', 'string', 'max:255'],
                'isbn' => ['nullable', 'string', 'max:20'],
                'editorial' => ['nullable', 'string', 'max:255'],
                'anio' => ['nullable', 'integer', 'between:1000,9999'],
                'portada_url' => ['nullable', 'url', 'max:255'],
                'mueble' => ['nullable', 'string', 'max:255'],
                'codigo_barras' => ['nullable', 'string', 'max:50', 'regex:/^[A-Za-z0-9-]+$/'],
                'estado' => ['nullable', 'in:disponible,extraviado,baja'],
                'observaciones' => ['nullable', 'string', 'max:1000'],
            ])->errors()->all();

            if ($errors) {
                if (fputcsv($report, [$line, implode(' ', $errors)]) === false) {
                    throw new \RuntimeException('No se pudo escribir el informe de importación.');
                }
                $rejected++;

                continue;
            }

            if (! empty($row['codigo_barras']) && Ejemplar::query()->where('codigo_barras', $row['codigo_barras'])->exists()) {
                if (fputcsv($report, [$line, 'El código de barras ya está registrado.']) === false) {
                    throw new \RuntimeException('No se pudo escribir el informe de importación.');
                }
                $rejected++;

                continue;
            }

            DB::transaction(function () use ($row, &$imported) {
                $mueble = null;
                if (! empty($row['mueble'])) {
                    $mueble = Mueble::query()->firstOrCreate(['nombre' => $row['mueble']]);
                }

                $libro = Libro::query()
                    ->where('titulo', $row['titulo'])
                    ->where('autor', $row['autor'])
                    ->where('isbn', $row['isbn'] ?? null)
                    ->first();

                if (! $libro) {
                    $libro = Libro::query()->create([
                        'titulo' => $row['titulo'],
                        'autor' => $row['autor'],
                        'isbn' => $row['isbn'] ?? null,
                        'editorial' => $row['editorial'] ?? null,
                        'anio' => $row['anio'] ?? null,
                        'portada_url' => $row['portada_url'] ?? null,
                        'mueble_id' => $mueble?->id,
                    ]);
                }

                if (! empty($row['codigo_barras'])) {
                    $libro->ejemplares()->create([
                        'codigo_barras' => $row['codigo_barras'],
                        'estado' => $row['estado'] ?? 'disponible',
                        'observaciones' => $row['observaciones'] ?? null,
                    ]);
                }

                $imported++;
            });
        }

        fclose($report);

        $this->info("Filas importadas: {$imported}. Filas rechazadas: {$rejected}. Informe: {$reportPath}");

        return $rejected > 0 ? self::FAILURE : self::SUCCESS;
    }
}
