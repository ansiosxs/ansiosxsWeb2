<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

class CrearVoluntario extends Command
{
    protected $signature = 'biblioteca:crear-voluntario';

    protected $description = 'Crea una cuenta de acceso para una persona voluntaria.';

    public function handle(): int
    {
        $datos = [
            'name' => $this->ask('Nombre'),
            'email' => $this->ask('Correo electrónico'),
            'password' => $this->secret('Contraseña (mínimo 12 caracteres)'),
        ];

        $validator = Validator::make($datos, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', Password::min(12)],
        ]);

        if ($validator->fails()) {
            foreach ($validator->errors()->all() as $error) {
                $this->error($error);
            }

            return self::FAILURE;
        }

        User::query()->create($validator->validated());
        $this->info('Cuenta voluntaria creada.');

        return self::SUCCESS;
    }
}
