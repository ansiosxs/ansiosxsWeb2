<?php

namespace Tests\Feature;

use App\Mail\RecordatorioVencimiento;
use App\Models\Anuncio;
use App\Models\Ejemplar;
use App\Models\Libro;
use App\Models\Prestamo;
use App\Models\Socio;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Tests\TestCase;

class BibliotecaTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->travelTo(now()->setDate(2026, 10, 16)->setTime(10, 0));
    }

    public function test_us01_guest_cannot_open_admin_and_volunteer_can_login(): void
    {
        $this->get('/admin')->assertRedirect('/login');

        $user = User::factory()->create(['email' => 'voluntaria@example.cl', 'password' => 'ClaveSegura123!']);
        $this->post('/login', ['email' => $user->email, 'password' => 'ClaveSegura123!'])
            ->assertRedirect(route('admin.dashboard'));

        $this->assertAuthenticatedAs($user);
    }

    public function test_us01_login_errors_are_generic_and_attempts_are_limited(): void
    {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $this->from('/login')->post('/login', ['email' => 'alguien@example.cl', 'password' => 'incorrecta'])
                ->assertSessionHasErrors(['email' => 'Las credenciales ingresadas no son correctas.']);
        }

        $this->from('/login')->post('/login', ['email' => 'alguien@example.cl', 'password' => 'incorrecta'])
            ->assertSessionHasErrors(['email' => 'Demasiados intentos. Intenta nuevamente en un minuto.']);
    }

    public function test_us02_book_requires_title_and_block_deactivation_while_loan_is_active(): void
    {
        $voluntario = User::factory()->create();
        $this->actingAs($voluntario)->from('/admin/libros/create')
            ->post(route('admin.libros.store'), ['titulo' => '', 'autor' => 'Autor'])
            ->assertSessionHasErrors('titulo');
        $this->assertDatabaseCount('libros', 0);

        [$libro, $ejemplar] = $this->createBookAndCopy('Libro prestado');
        $socio = $this->createMember();
        $this->createActiveLoan($socio, $ejemplar, $voluntario);

        $this->actingAs($voluntario)->delete(route('admin.libros.destroy', $libro))
            ->assertSessionHasErrors('libro');
        $this->assertDatabaseHas('libros', ['id' => $libro->id, 'deleted_at' => null]);
    }

    public function test_us02_book_with_loan_history_is_soft_deleted_and_copies_are_retired(): void
    {
        $voluntario = User::factory()->create();
        [$libro, $ejemplar] = $this->createBookAndCopy('Libro con historial');
        $prestamo = $this->createActiveLoan($this->createMember(), $ejemplar, $voluntario, today()->subDay());
        $prestamo->update([
            'estado' => 'devuelto',
            'fecha_devolucion' => now(),
            'devuelto_por_user_id' => $voluntario->id,
            'ejemplar_activo_id' => null,
        ]);
        $ejemplar->update(['estado' => 'disponible']);
        $this->travelTo(now()->addDay());

        $this->actingAs($voluntario)->delete(route('admin.libros.destroy', $libro))
            ->assertRedirect(route('admin.libros.index'));
        $this->assertSoftDeleted('libros', ['id' => $libro->id]);
        $this->assertDatabaseHas('ejemplares', ['id' => $ejemplar->id, 'estado' => 'baja']);
    }

    public function test_us03_duplicate_barcode_reports_existing_title(): void
    {
        $voluntario = User::factory()->create();
        [$existing] = $this->createBookAndCopy('Libro asociado', 'BIB-004');
        $other = Libro::create(['titulo' => 'Otro libro', 'autor' => 'Otra persona']);

        $this->actingAs($voluntario)->from(route('admin.libros.ejemplares.create', $other))
            ->post(route('admin.libros.ejemplares.store', $other), ['codigo_barras' => 'BIB-004'])
            ->assertSessionHasErrors(['codigo_barras' => "Este código ya está registrado en el libro «{$existing->titulo}»."]);
    }

    public function test_us04_rejects_invalid_run_and_normalizes_valid_member_data(): void
    {
        $voluntario = User::factory()->create();
        $payload = [
            'run' => '12.345.678-4',
            'nombres' => 'Camila',
            'apellidos' => 'Lectora',
            'telefono' => '987654321',
            'comuna' => 'Concepción',
        ];

        $this->actingAs($voluntario)->from(route('admin.socios.create'))
            ->post(route('admin.socios.store'), $payload)
            ->assertSessionHasErrors('run');
        $this->assertDatabaseCount('socios', 0);

        $payload['run'] = '12.345.678-5';
        $this->actingAs($voluntario)->post(route('admin.socios.store'), $payload)
            ->assertRedirect();
        $this->assertDatabaseHas('socios', [
            'run' => '123456785',
            'telefono' => '+56 9 8765 4321',
            'vigente_hasta' => today()->addYear()->format('Y-m-d').' 00:00:00',
        ]);

        $payload['run'] = '12345678-5';
        $this->actingAs($voluntario)->from(route('admin.socios.create'))
            ->post(route('admin.socios.store'), $payload)
            ->assertSessionHasErrors('run');
    }

    public function test_us05_borrow_uses_configured_due_date_and_retries_are_idempotent(): void
    {
        $voluntario = User::factory()->create();
        $socio = $this->createMember();
        [, $ejemplar] = $this->createBookAndCopy('Una lectura', 'RETRY-01');
        $uuid = (string) Str::uuid();
        $payload = ['codigo_barras' => $ejemplar->codigo_barras, 'socio_id' => $socio->id, 'operacion_uuid' => $uuid];

        $this->actingAs($voluntario)->postJson(route('admin.prestamos.store'), $payload)
            ->assertOk()->assertJsonPath('redireccion', route('admin.prestamos.index'));
        $this->postJson(route('admin.prestamos.store'), $payload)->assertOk();

        $this->assertDatabaseCount('prestamos', 1);
        $this->assertDatabaseHas('prestamos', [
            'ejemplar_id' => $ejemplar->id,
            'fecha_vencimiento' => today()->addDays(14)->format('Y-m-d').' 00:00:00',
            'estado' => 'activo',
            'ejemplar_activo_id' => $ejemplar->id,
            'user_id' => $voluntario->id,
        ]);
        $this->assertDatabaseHas('ejemplares', ['id' => $ejemplar->id, 'estado' => 'prestado']);
    }

    public function test_us05_rejects_overdue_member_expired_membership_and_maximum_loans(): void
    {
        $voluntario = User::factory()->create();
        [$bookA, $copyA] = $this->createBookAndCopy('A', 'LIMIT-A');
        $overdue = $this->createMember();
        $this->createActiveLoan($overdue, $copyA, $voluntario, today()->subDay());
        [, $copyB] = $this->createBookAndCopy('B', 'LIMIT-B');
        [, $copyC] = $this->createBookAndCopy('C', 'LIMIT-C');

        $this->actingAs($voluntario)->from(route('admin.prestamos.index'))
            ->post(route('admin.prestamos.store'), [
                'codigo_barras' => $copyB->codigo_barras,
                'socio_id' => $overdue->id,
                'operacion_uuid' => (string) Str::uuid(),
            ])->assertSessionHasErrors('socio_id');

        $expired = $this->createMember(['vigente_hasta' => today()->subDay()]);
        $this->post(route('admin.prestamos.store'), [
            'codigo_barras' => $copyB->codigo_barras,
            'socio_id' => $expired->id,
            'operacion_uuid' => (string) Str::uuid(),
        ])->assertSessionHasErrors('socio_id');

        $limited = $this->createMember();
        $this->createActiveLoan($limited, $bookA->ejemplares()->create(['codigo_barras' => 'LIMIT-A2']), $voluntario);
        $this->createActiveLoan($limited, $this->createBookAndCopy('Otro', 'LIMIT-X')[1], $voluntario);
        $this->post(route('admin.prestamos.store'), [
            'codigo_barras' => $copyC->codigo_barras,
            'socio_id' => $limited->id,
            'operacion_uuid' => (string) Str::uuid(),
        ])->assertSessionHasErrors('socio_id');
    }

    public function test_us05_rejects_non_available_copy_and_database_enforces_one_active_loan(): void
    {
        $voluntario = User::factory()->create();
        $socio = $this->createMember();
        [, $ejemplar] = $this->createBookAndCopy('No disponible');
        $ejemplar->update(['estado' => 'extraviado']);

        $this->actingAs($voluntario)->from(route('admin.prestamos.index'))
            ->post(route('admin.prestamos.store'), [
                'codigo_barras' => $ejemplar->codigo_barras,
                'socio_id' => $socio->id,
                'operacion_uuid' => (string) Str::uuid(),
            ])->assertSessionHasErrors('codigo_barras');

        $ejemplar->update(['estado' => 'disponible']);
        $this->createActiveLoan($socio, $ejemplar, $voluntario);
        $this->expectException(QueryException::class);
        $this->createActiveLoan($this->createMember(), $ejemplar, $voluntario);
    }

    public function test_us06_return_closes_loan_and_records_late_days(): void
    {
        $voluntario = User::factory()->create();
        [, $ejemplar] = $this->createBookAndCopy('Atrasado');
        $prestamo = $this->createActiveLoan($this->createMember(), $ejemplar, $voluntario, today()->subDays(3));

        $this->actingAs($voluntario)->from(route('admin.prestamos.index'))
            ->post(route('admin.prestamos.devolver'), ['codigo_barras' => $ejemplar->codigo_barras])
            ->assertSessionHas('status', 'Devolución registrada. El libro tenía 3 días de atraso.');
        $this->assertDatabaseHas('prestamos', [
            'id' => $prestamo->id,
            'estado' => 'devuelto',
            'devuelto_por_user_id' => $voluntario->id,
            'ejemplar_activo_id' => null,
        ]);
        $this->assertDatabaseHas('ejemplares', ['id' => $ejemplar->id, 'estado' => 'disponible']);
    }

    public function test_us06_returning_a_copy_without_an_active_loan_does_not_change_it(): void
    {
        $voluntario = User::factory()->create();
        [, $ejemplar] = $this->createBookAndCopy('Sin préstamo activo');

        $this->actingAs($voluntario)->from(route('admin.prestamos.index'))
            ->post(route('admin.prestamos.devolver'), ['codigo_barras' => $ejemplar->codigo_barras])
            ->assertSessionHasErrors('codigo_barras');
        $this->assertDatabaseHas('ejemplares', ['id' => $ejemplar->id, 'estado' => 'disponible']);
        $this->assertDatabaseCount('prestamos', 0);
    }

    public function test_us07_morosity_page_lists_only_overdue_active_loans(): void
    {
        $voluntario = User::factory()->create();
        [, $ejemplar] = $this->createBookAndCopy('Vencido');
        $this->createActiveLoan($this->createMember(), $ejemplar, $voluntario, today()->subDay());

        $this->actingAs($voluntario)->get(route('admin.morosidad'))
            ->assertOk()->assertSee('Vencido')->assertSee('1');
    }

    public function test_us08_public_catalog_never_exposes_barcodes_or_personal_data(): void
    {
        [$libro, $ejemplar] = $this->createBookAndCopy('Catálogo público', 'CODIGO-PRIVADO');
        $this->createMember(['nombres' => 'Dato privado']);

        $response = $this->getJson('/api/catalogo?q=Catálogo');
        $response->assertOk()
            ->assertJsonPath('datos.0.titulo', $libro->titulo)
            ->assertJsonPath('datos.0.ejemplares_disponibles', 1)
            ->assertJsonMissingPath('datos.0.socio')
            ->assertJsonMissingPath('datos.0.prestamos');
        $this->assertStringNotContainsString($ejemplar->codigo_barras, $response->getContent());
        $this->assertStringNotContainsString('Dato privado', $response->getContent());
        $this->getJson('/api/catalogo?pagina=0')->assertStatus(422)
            ->assertJsonStructure(['mensaje', 'errores']);
    }

    public function test_us09_announcements_are_public_only_during_their_date_window(): void
    {
        $user = User::factory()->create();
        Anuncio::create([
            'titulo' => 'Anuncio vigente',
            'cuerpo' => 'Información pública',
            'publicar_desde' => today()->subDay(),
            'publicar_hasta' => today()->addDay(),
            'user_id' => $user->id,
        ]);
        Anuncio::create([
            'titulo' => 'Anuncio futuro',
            'cuerpo' => 'Todavía no',
            'publicar_desde' => today()->addDay(),
            'user_id' => $user->id,
        ]);

        $this->get('/')->assertOk()->assertSee('Anuncio vigente')->assertDontSee('Anuncio futuro');
    }

    public function test_us10_reminder_email_is_sent_and_recorded_only_once(): void
    {
        Mail::fake();
        $voluntario = User::factory()->create();
        $socio = $this->createMember(['email' => 'lector@example.cl']);
        [, $ejemplar] = $this->createBookAndCopy('Recordatorio');
        $this->createActiveLoan($socio, $ejemplar, $voluntario, today()->addDays(2));

        $this->artisan('biblioteca:enviar-recordatorios')->assertSuccessful();
        $this->artisan('biblioteca:enviar-recordatorios')->assertSuccessful();

        Mail::assertSentTimes(RecordatorioVencimiento::class, 1);
        $this->assertDatabaseCount('recordatorios', 1);
    }

    public function test_admin_views_render_for_authenticated_volunteer(): void
    {
        $voluntario = User::factory()->create();
        [$libro, $ejemplar] = $this->createBookAndCopy('Vistas');
        $socio = $this->createMember();
        $this->createActiveLoan($socio, $ejemplar, $voluntario);
        Anuncio::create([
            'titulo' => 'Aviso',
            'cuerpo' => 'Texto',
            'publicar_desde' => today(),
            'user_id' => $voluntario->id,
        ]);

        $this->actingAs($voluntario);
        foreach ([
            route('admin.dashboard'),
            route('admin.estadisticas'),
            route('admin.libros.index'),
            route('admin.libros.create'),
            route('admin.libros.show', $libro),
            route('admin.libros.edit', $libro),
            route('admin.libros.ejemplares.index', $libro),
            route('admin.libros.ejemplares.create', $libro),
            route('admin.socios.index'),
            route('admin.socios.create'),
            route('admin.socios.show', $socio),
            route('admin.socios.edit', $socio),
            route('admin.prestamos.index'),
            route('admin.morosidad'),
            route('admin.anuncios.index'),
            route('admin.anuncios.create'),
            route('admin.anuncios.edit', Anuncio::first()),
            route('admin.muebles.index'),
        ] as $url) {
            $this->get($url)->assertOk();
        }
    }

    public function test_catalog_import_handles_excel_csv_and_reports_rejected_rows(): void
    {
        $csv = tempnam(sys_get_temp_dir(), 'insectaria-csv-');
        $report = tempnam(sys_get_temp_dir(), 'insectaria-report-');
        file_put_contents($csv, "\xEF\xBB\xBFtitulo,autor,codigo_barras,mueble\nLibro,Autora,CAT-001,Sala infantil\nLibro,Autora,CAT-001,Sala infantil\n");

        try {
            $this->artisan('biblioteca:importar-catalogo', ['archivo' => $csv, '--reporte' => $report])
                ->expectsOutputToContain('Filas importadas: 1. Filas rechazadas: 1.')
                ->assertExitCode(1);
            $this->assertDatabaseCount('libros', 1);
            $this->assertDatabaseCount('ejemplares', 1);
            $this->assertStringContainsString('ya está registrado', file_get_contents($report));
        } finally {
            unlink($csv);
            unlink($report);
        }
    }

    private function createBookAndCopy(string $title, string $barcode = 'COD-001'): array
    {
        $book = Libro::create(['titulo' => $title, 'autor' => 'Autora de prueba']);
        $copy = $book->ejemplares()->create(['codigo_barras' => $barcode]);

        return [$book, $copy];
    }

    private function createMember(array $overrides = []): Socio
    {
        return Socio::create(array_merge([
            'run' => (string) random_int(10000000, 99999999).'K',
            'nombres' => 'Persona',
            'apellidos' => 'Lectora',
            'telefono' => '+56 9 1234 5678',
            'email' => null,
            'comuna' => 'Concepción',
            'ocupacion' => null,
            'fecha_inscripcion' => today(),
            'vigente_hasta' => today()->addYear(),
            'activo' => true,
        ], $overrides));
    }

    private function createActiveLoan(Socio $socio, Ejemplar $ejemplar, User $voluntario, $dueDate = null): Prestamo
    {
        $ejemplar->update(['estado' => 'prestado']);

        return Prestamo::create([
            'socio_id' => $socio->id,
            'ejemplar_id' => $ejemplar->id,
            'user_id' => $voluntario->id,
            'fecha_prestamo' => now(),
            'fecha_vencimiento' => $dueDate ?? today()->addDays(14),
            'estado' => 'activo',
            'ejemplar_activo_id' => $ejemplar->id,
            'operacion_uuid' => (string) Str::uuid(),
        ]);
    }
}
