
<?php $__env->startSection('title', 'Ejemplares de '.$libro->titulo); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow"><a href="<?php echo e(route('admin.libros.show', $libro)); ?>"><?php echo e($libro->titulo); ?></a></p><h1>Ejemplares</h1></div><a class="button" href="<?php echo e(route('admin.libros.ejemplares.create', $libro)); ?>">Registrar ejemplar</a></div>
<div class="table-wrap"><table><thead><tr><th>Código de barras</th><th>Estado</th><th>Observaciones</th><th></th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $ejemplares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ejemplar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($ejemplar->codigo_barras); ?></td><td>
    <?php if($ejemplar->estado === 'prestado'): ?>Prestado
    <?php else: ?>
    <form class="inline-form" method="post" action="<?php echo e(route('admin.libros.ejemplares.update', [$libro, $ejemplar])); ?>"><?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
        <select name="estado" aria-label="Estado de <?php echo e($ejemplar->codigo_barras); ?>"><option value="disponible" <?php if($ejemplar->estado === 'disponible'): echo 'selected'; endif; ?>>Disponible</option><option value="extraviado" <?php if($ejemplar->estado === 'extraviado'): echo 'selected'; endif; ?>>Extraviado</option><option value="baja" <?php if($ejemplar->estado === 'baja'): echo 'selected'; endif; ?>>Baja</option></select><button class="link-button">Guardar</button>
    </form>
    <?php endif; ?>
    </td><td><?php echo e($ejemplar->observaciones); ?></td><td><?php if($ejemplar->estado !== 'prestado'): ?><form method="post" action="<?php echo e(route('admin.libros.ejemplares.destroy', [$libro, $ejemplar])); ?>"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button class="link-button">Eliminar registro</button></form><?php endif; ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4">Todavía no hay ejemplares.</td></tr><?php endif; ?>
</tbody></table></div><?php echo e($ejemplares->links()); ?>

<section class="panel"><h2>Registrar siguiente ejemplar</h2>
    <form class="form-stack" method="post" action="<?php echo e(route('admin.libros.ejemplares.store', $libro)); ?>">
        <?php echo csrf_field(); ?>
        <label>Código de barras<input id="codigo-barras" name="codigo_barras" value="<?php echo e(old('codigo_barras')); ?>" maxlength="50" pattern="[A-Za-z0-9-]+" required autocomplete="off" autofocus><?php $__errorArgs = ['codigo_barras'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
        <label>Observaciones<textarea name="observaciones" rows="2"></textarea></label>
        <button class="button" type="submit">Guardar ejemplar</button>
    </form>
</section>
<?php if(session('focus_codigo')): ?><script>document.addEventListener('DOMContentLoaded', () => document.getElementById('codigo-barras')?.focus());</script><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/ejemplares/index.blade.php ENDPATH**/ ?>