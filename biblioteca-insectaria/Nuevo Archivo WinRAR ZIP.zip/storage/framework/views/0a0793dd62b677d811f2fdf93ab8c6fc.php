
<?php $__env->startSection('title', $socio->exists ? 'Editar socio' : 'Inscribir socio'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Membresías</p><h1><?php echo e($socio->exists ? 'Editar socio' : 'Inscribir socio'); ?></h1></div><a href="<?php echo e(route('admin.socios.index')); ?>">Volver</a></div>
<form class="panel form-stack" method="post" action="<?php echo e($socio->exists ? route('admin.socios.update', $socio) : route('admin.socios.store')); ?>">
    <?php echo csrf_field(); ?> <?php if($socio->exists): ?> <?php echo method_field('put'); ?> <?php endif; ?>
    <div class="grid-two"><label>RUN *<input name="run" value="<?php echo e(old('run', $socio->run)); ?>" placeholder="12.345.678-5" maxlength="15" required><?php $__errorArgs = ['run'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label><label>Celular *<input name="telefono" type="tel" value="<?php echo e(old('telefono', $socio->telefono)); ?>" placeholder="+56 9 1234 5678" required><?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label></div>
    <div class="grid-two"><label>Nombres *<input name="nombres" value="<?php echo e(old('nombres', $socio->nombres)); ?>" required maxlength="255"><?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label><label>Apellidos *<input name="apellidos" value="<?php echo e(old('apellidos', $socio->apellidos)); ?>" required maxlength="255"><?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label></div>
    <div class="grid-two"><label>Comuna *<input name="comuna" value="<?php echo e(old('comuna', $socio->comuna)); ?>" required maxlength="255"><?php $__errorArgs = ['comuna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label><label>Ocupación<input name="ocupacion" value="<?php echo e(old('ocupacion', $socio->ocupacion)); ?>" maxlength="255"><?php $__errorArgs = ['ocupacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label></div>
    <label>Correo electrónico (opcional)<input name="email" type="email" value="<?php echo e(old('email', $socio->email)); ?>" maxlength="255"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
    <button class="button" type="submit">Guardar socio</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/socios/form.blade.php ENDPATH**/ ?>