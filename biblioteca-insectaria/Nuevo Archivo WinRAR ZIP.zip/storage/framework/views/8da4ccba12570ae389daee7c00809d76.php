
<?php $__env->startSection('title', 'Muebles'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Ubicación física</p><h1>Muebles y secciones</h1></div></div>
<form class="panel form-stack compact-form" method="post" action="<?php echo e(route('admin.muebles.store')); ?>"><?php echo csrf_field(); ?><h2>Agregar mueble</h2><label>Nombre *<input name="nombre" required maxlength="255"></label><label>Descripción<textarea name="descripcion" rows="2"></textarea></label><button class="button">Guardar mueble</button></form>
<div class="table-wrap"><table><thead><tr><th>Nombre</th><th>Descripción</th><th>Libros asignados</th><th>Acciones</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $muebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($mueble->nombre); ?></td><td><?php echo e($mueble->descripcion); ?></td><td><?php echo e($mueble->libros_count); ?></td><td class="actions">
<details><summary>Editar</summary><form class="form-stack compact-form" method="post" action="<?php echo e(route('admin.muebles.update', $mueble)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('put'); ?><label>Nombre<input name="nombre" value="<?php echo e($mueble->nombre); ?>" required></label><label>Descripción<textarea name="descripcion"><?php echo e($mueble->descripcion); ?></textarea></label><button class="button button-secondary">Guardar cambios</button></form></details>
<form method="post" action="<?php echo e(route('admin.muebles.destroy', $mueble)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button class="link-button">Eliminar</button></form></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4">No hay muebles registrados.</td></tr><?php endif; ?>
</tbody></table></div><?php echo e($muebles->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/muebles/index.blade.php ENDPATH**/ ?>