
<?php $__env->startSection('title', $anuncio->exists ? 'Editar anuncio' : 'Crear anuncio'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Portal público</p><h1><?php echo e($anuncio->exists ? 'Editar anuncio' : 'Crear anuncio'); ?></h1></div><a href="<?php echo e(route('admin.anuncios.index')); ?>">Volver</a></div>
<form class="panel form-stack" method="post" action="<?php echo e($anuncio->exists ? route('admin.anuncios.update', $anuncio) : route('admin.anuncios.store')); ?>">
    <?php echo csrf_field(); ?> <?php if($anuncio->exists): ?> <?php echo method_field('put'); ?> <?php endif; ?>
    <label>Título *<input name="titulo" value="<?php echo e(old('titulo', $anuncio->titulo)); ?>" maxlength="255" required><?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
    <label>Texto *<textarea name="cuerpo" rows="6" required><?php echo e(old('cuerpo', $anuncio->cuerpo)); ?></textarea><?php $__errorArgs = ['cuerpo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
    <div class="grid-two"><label>Publicar desde *<input name="publicar_desde" type="date" value="<?php echo e(old('publicar_desde', $anuncio->publicar_desde?->format('Y-m-d'))); ?>" required><?php $__errorArgs = ['publicar_desde'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label><label>Publicar hasta<input name="publicar_hasta" type="date" value="<?php echo e(old('publicar_hasta', $anuncio->publicar_hasta?->format('Y-m-d'))); ?>"><?php $__errorArgs = ['publicar_hasta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label></div>
    <button class="button" type="submit">Guardar anuncio</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/anuncios/form.blade.php ENDPATH**/ ?>