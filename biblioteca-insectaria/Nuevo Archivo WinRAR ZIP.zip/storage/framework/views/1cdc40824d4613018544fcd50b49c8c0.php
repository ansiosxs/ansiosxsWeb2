
<?php $__env->startSection('title', $libro->exists ? 'Editar libro' : 'Nuevo libro'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Catálogo</p><h1><?php echo e($libro->exists ? 'Editar libro' : 'Agregar libro'); ?></h1></div><a href="<?php echo e(route('admin.libros.index')); ?>">Volver a libros</a></div>
<form class="panel form-stack" method="post" action="<?php echo e($libro->exists ? route('admin.libros.update', $libro) : route('admin.libros.store')); ?>">
    <?php echo csrf_field(); ?> <?php if($libro->exists): ?> <?php echo method_field('put'); ?> <?php endif; ?>
    <label>Título *<input name="titulo" value="<?php echo e(old('titulo', $libro->titulo)); ?>" required maxlength="255"><?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
    <label>Autor *<input name="autor" value="<?php echo e(old('autor', $libro->autor)); ?>" required maxlength="255"><?php $__errorArgs = ['autor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
    <div class="grid-two"><label>ISBN<input name="isbn" value="<?php echo e(old('isbn', $libro->isbn)); ?>" maxlength="20"></label><label>Editorial<input name="editorial" value="<?php echo e(old('editorial', $libro->editorial)); ?>" maxlength="255"></label></div>
    <div class="grid-two"><label>Año<input name="anio" type="number" min="1000" max="9999" value="<?php echo e(old('anio', $libro->anio)); ?>"></label><label>URL de portada<input name="portada_url" type="url" value="<?php echo e(old('portada_url', $libro->portada_url)); ?>"></label></div>
    <label>Mueble o sección<select name="mueble_id"><option value="">Sin asignar</option><?php $__currentLoopData = $muebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($mueble->id); ?>" <?php if(old('mueble_id', $libro->mueble_id) == $mueble->id): echo 'selected'; endif; ?>><?php echo e($mueble->nombre); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
    <button class="button" type="submit">Guardar libro</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/libros/form.blade.php ENDPATH**/ ?>