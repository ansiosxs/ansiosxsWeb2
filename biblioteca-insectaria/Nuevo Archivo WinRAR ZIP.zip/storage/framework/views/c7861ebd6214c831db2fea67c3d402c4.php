
<?php $__env->startSection('title', 'Préstamos'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Circulación</p><h1>Préstamos y devoluciones</h1></div><a href="<?php echo e(route('admin.morosidad')); ?>">Ver morosidad</a></div>
<div class="grid-two">
    <section class="panel"><h2>Registrar préstamo</h2><p>Escanea el ejemplar, selecciona al socio y confirma.</p>
        <form class="form-stack" method="post" action="<?php echo e(route('admin.prestamos.store')); ?>" data-resiliente="prestamo">
            <?php echo csrf_field(); ?>
            <label>Código del ejemplar<input name="codigo_barras" value="<?php echo e(old('codigo_barras')); ?>" required autofocus autocomplete="off"><?php $__errorArgs = ['codigo_barras'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
            <label>Socio<select name="socio_id" required><option value="">Selecciona un socio</option><?php $__currentLoopData = $socios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($socio->id); ?>" <?php if(old('socio_id') == $socio->id): echo 'selected'; endif; ?>><?php echo e($socio->apellidos); ?>, <?php echo e($socio->nombres); ?> — <?php echo e($socio->run); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['socio_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
            <input type="hidden" name="operacion_uuid" value="<?php echo e($operacionUuid); ?>">
            <button class="button" type="submit">Confirmar préstamo</button>
            <div class="resilience-notice" hidden role="alert"></div>
        </form>
    </section>
    <section class="panel"><h2>Registrar devolución</h2><p>Escanea el código del ejemplar para devolverlo.</p>
        <form class="form-stack" method="post" action="<?php echo e(route('admin.prestamos.devolver')); ?>" data-resiliente="devolucion">
            <?php echo csrf_field(); ?>
            <label>Código del ejemplar<input name="codigo_barras" required autocomplete="off"><?php $__errorArgs = ['codigo_barras'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
            <button class="button button-secondary" type="submit">Registrar devolución</button>
            <div class="resilience-notice" hidden role="alert"></div>
        </form>
    </section>
</div>
<section class="panel"><h2>Préstamos activos</h2><div class="table-wrap"><table><thead><tr><th>Libro y código</th><th>Socio</th><th>Fecha de salida</th><th>Vencimiento</th><th>Estado</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($prestamo->ejemplar->libro->titulo); ?><br><span class="muted"><?php echo e($prestamo->ejemplar->codigo_barras); ?></span></td><td><?php echo e($prestamo->socio->nombres); ?> <?php echo e($prestamo->socio->apellidos); ?><br><span class="muted"><?php echo e($prestamo->socio->telefono); ?></span></td><td><?php echo e($prestamo->fecha_prestamo->format('d/m/Y')); ?></td><td><?php echo e($prestamo->fecha_vencimiento->format('d/m/Y')); ?></td><td><?php echo e($prestamo->fecha_vencimiento->lt(today()) ? 'Vencido' : 'Activo'); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5">No hay préstamos activos.</td></tr><?php endif; ?>
</tbody></table></div><?php echo e($prestamos->links()); ?></section>
<section class="panel"><h2>Contactar por teléfono</h2><p>Préstamos que vencen pronto y cuyos socios no tienen correo registrado.</p>
<?php $__empty_1 = true; $__currentLoopData = $contactar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><p><?php echo e($prestamo->socio->nombres); ?> <?php echo e($prestamo->socio->apellidos); ?> · <?php echo e($prestamo->socio->telefono); ?> · <?php echo e($prestamo->ejemplar->libro->titulo); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p>No hay contactos pendientes.</p><?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/prestamos/index.blade.php ENDPATH**/ ?>