
<?php $__env->startSection('title', 'Ficha de socio'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Ficha de socio</p><h1><?php echo e($socio->nombres); ?> <?php echo e($socio->apellidos); ?></h1></div><a class="button button-secondary" href="<?php echo e(route('admin.socios.edit', $socio)); ?>">Editar datos</a></div>
<section class="panel">
    <p><strong>RUN:</strong> <?php echo e($socio->run); ?></p><p><strong>Teléfono:</strong> <?php echo e($socio->telefono); ?></p><p><strong>Correo:</strong> <?php echo e($socio->email ?? 'No informado'); ?></p>
    <p><strong>Comuna:</strong> <?php echo e($socio->comuna); ?> · <strong>Ocupación:</strong> <?php echo e($socio->ocupacion ?? 'No informada'); ?></p>
    <p><strong>Membresía hasta:</strong> <?php echo e($socio->vigente_hasta->format('d/m/Y')); ?> · <strong>Estado:</strong> <?php echo e($socio->activo ? ($socio->vigente_hasta->lt(today()) ? 'Vencida' : 'Vigente') : 'Inactivo'); ?></p>
    <form method="post" action="<?php echo e(route('admin.socios.renovar', $socio)); ?>"><?php echo csrf_field(); ?><button class="button" type="submit">Renovar membresía por un año</button></form>
</section>
<section class="panel"><h2>Historial de préstamos</h2><div class="table-wrap"><table><thead><tr><th>Libro</th><th>Préstamo</th><th>Vencimiento</th><th>Devolución</th><th>Estado</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $socio->prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($prestamo->ejemplar->libro->titulo); ?></td><td><?php echo e($prestamo->fecha_prestamo->format('d/m/Y')); ?></td><td><?php echo e($prestamo->fecha_vencimiento->format('d/m/Y')); ?></td><td><?php echo e($prestamo->fecha_devolucion?->format('d/m/Y') ?? '—'); ?></td><td><?php echo e(ucfirst($prestamo->estado)); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5">Sin préstamos registrados.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/socios/show.blade.php ENDPATH**/ ?>