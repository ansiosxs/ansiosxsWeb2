
<?php $__env->startSection('title', 'Anuncios'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Portal público</p><h1>Anuncios</h1></div><a class="button" href="<?php echo e(route('admin.anuncios.create')); ?>">Crear anuncio</a></div>
<div class="table-wrap"><table><thead><tr><th>Título</th><th>Desde</th><th>Hasta</th><th>Estado</th><th></th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($anuncio->titulo); ?></td><td><?php echo e($anuncio->publicar_desde->format('d/m/Y')); ?></td><td><?php echo e($anuncio->publicar_hasta?->format('d/m/Y') ?? 'Sin fecha de término'); ?></td><td><?php echo e($anuncio->publicar_desde->lte(today()) && (! $anuncio->publicar_hasta || $anuncio->publicar_hasta->gte(today())) ? 'Publicado' : 'No publicado'); ?></td><td class="actions"><a href="<?php echo e(route('admin.anuncios.edit', $anuncio)); ?>">Editar</a><form method="post" action="<?php echo e(route('admin.anuncios.destroy', $anuncio)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button class="link-button">Despublicar</button></form></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5">No hay anuncios.</td></tr><?php endif; ?>
</tbody></table></div><?php echo e($anuncios->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/anuncios/index.blade.php ENDPATH**/ ?>