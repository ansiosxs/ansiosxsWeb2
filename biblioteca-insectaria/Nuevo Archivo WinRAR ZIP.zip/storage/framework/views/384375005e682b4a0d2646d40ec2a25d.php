
<?php $__env->startSection('title', 'Morosidad'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Circulación</p><h1>Préstamos vencidos</h1></div><a href="<?php echo e(route('admin.prestamos.index')); ?>">Volver a préstamos</a></div>
<div class="table-wrap"><table><thead><tr><th>Socio</th><th>Teléfono</th><th>Libro</th><th>Vencimiento</th><th>Días de atraso</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($prestamo->socio->nombres); ?> <?php echo e($prestamo->socio->apellidos); ?></td><td><?php echo e($prestamo->socio->telefono); ?></td><td><?php echo e($prestamo->ejemplar->libro->titulo); ?></td><td><?php echo e($prestamo->fecha_vencimiento->format('d/m/Y')); ?></td><td><?php echo e($prestamo->fecha_vencimiento->diffInDays(today())); ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5">No hay préstamos vencidos.</td></tr><?php endif; ?>
</tbody></table></div><?php echo e($prestamos->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/prestamos/morosidad.blade.php ENDPATH**/ ?>