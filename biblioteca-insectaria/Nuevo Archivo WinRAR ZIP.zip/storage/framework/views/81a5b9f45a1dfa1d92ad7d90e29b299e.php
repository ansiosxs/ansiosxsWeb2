<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Consulta el catálogo público de la Biblioteca Comunitaria Insectaria.">
    <title>Catálogo | Biblioteca Insectaria</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="public-page">
    <header class="public-header">
        <div class="public-header-inner"><a class="brand" href="<?php echo e(route('catalogo')); ?>">Biblioteca Comunitaria Insectaria</a>
            <a href="<?php echo e(route('login')); ?>">Acceso voluntariado</a>
        </div>
    </header>
    <main class="catalog-main">
        <section class="catalog-intro"><p class="eyebrow">Concepción, Chile</p><h1>Explora nuestro catálogo</h1><p>Busca libros y revisa su disponibilidad antes de visitarnos.</p></section>
        <?php if($anuncios->isNotEmpty()): ?>
            <section class="announcements" aria-label="Anuncios">
                <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><article class="announcement"><h2><?php echo e($anuncio->titulo); ?></h2><p><?php echo e($anuncio->cuerpo); ?></p></article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>
        <div id="catalog-app" aria-live="polite"></div>
    </main>
    <footer class="public-footer">Biblioteca Comunitaria Insectaria · Los datos de disponibilidad pueden cambiar durante el día.</footer>
    <script>if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch((error) => console.error('No se pudo registrar el caché del catálogo:', error)));</script>
</body>
</html>
<?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/catalogo/index.blade.php ENDPATH**/ ?>