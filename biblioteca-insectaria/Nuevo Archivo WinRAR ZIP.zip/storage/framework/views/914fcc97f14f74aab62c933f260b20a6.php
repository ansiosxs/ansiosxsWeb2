
<?php $__env->startSection('title', 'Socios'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Membresías</p><h1>Socios</h1></div><a class="button" href="<?php echo e(route('admin.socios.create')); ?>">Inscribir socio</a></div>
<form class="search-form" method="get"><label for="q">Buscar por nombre o RUN</label><div class="inline-form"><input id="q" name="q" value="<?php echo e($q); ?>" type="search"><button class="button">Buscar</button></div></form>
<div class="table-wrap"><table><thead><tr><th>Socio</th><th>RUN</th><th>Comuna</th><th>Vigente hasta</th><th>Estado</th><th></th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $socios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($socio->nombres); ?> <?php echo e($socio->apellidos); ?></td><td><?php echo e($socio->run); ?></td><td><?php echo e($socio->comuna); ?></td><td><?php echo e($socio->vigente_hasta->format('d/m/Y')); ?></td><td><?php echo e($socio->activo ? ($socio->vigente_hasta->lt(today()) ? 'Vencida' : 'Vigente') : 'Inactivo'); ?></td><td><a href="<?php echo e(route('admin.socios.show', $socio)); ?>">Ficha</a></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6">No hay socios para mostrar.</td></tr><?php endif; ?>
</tbody></table></div><?php echo e($socios->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/socios/index.blade.php ENDPATH**/ ?>