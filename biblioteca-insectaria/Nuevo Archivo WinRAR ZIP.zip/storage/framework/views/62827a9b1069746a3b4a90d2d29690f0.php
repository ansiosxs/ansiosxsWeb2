
<?php $__env->startSection('title', 'Registrar ejemplar'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow"><?php echo e($libro->titulo); ?></p><h1>Registrar ejemplar</h1></div><a href="<?php echo e(route('admin.libros.ejemplares.index', $libro)); ?>">Volver</a></div>
<form class="panel form-stack" method="post" action="<?php echo e(route('admin.libros.ejemplares.store', $libro)); ?>">
    <?php echo csrf_field(); ?>
    <label>Código de barras<input id="codigo-barras" name="codigo_barras" value="<?php echo e(old('codigo_barras')); ?>" maxlength="50" pattern="[A-Za-z0-9-]+" required autofocus autocomplete="off" inputmode="text"><?php $__errorArgs = ['codigo_barras'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="field-error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
    <p class="muted">El lector USB puede escribir el código en este campo. Se validará antes de registrar el ejemplar.</p>
    <label>Observaciones<textarea name="observaciones" rows="3"><?php echo e(old('observaciones')); ?></textarea></label>
    <button class="button" type="submit">Guardar ejemplar</button>
</form>
<?php if(session('focus_codigo')): ?><script>document.addEventListener('DOMContentLoaded', () => document.getElementById('codigo-barras')?.focus());</script><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/ejemplares/form.blade.php ENDPATH**/ ?>