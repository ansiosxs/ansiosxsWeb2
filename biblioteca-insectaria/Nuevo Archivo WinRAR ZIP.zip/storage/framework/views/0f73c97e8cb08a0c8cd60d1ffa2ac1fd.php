
<?php $__env->startSection('title', 'Resumen'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Panel de gestión</p><h2 class="font-display text-2xl font-bold text-[#35234f] sm:text-3xl">Resumen de la biblioteca</h2><p class="muted mb-0">Estado actual y accesos rápidos para el equipo.</p></div></div>
<div class="stats-grid">
    <article class="stat-card"><span class="font-semibold text-[#716c77]">Socios con membresía vigente</span><strong><?php echo e($sociosActivos); ?></strong><span class="text-sm text-[#716c77]">Membresías activas</span></article>
    <article class="stat-card"><span class="font-semibold text-[#716c77]">Préstamos vencidos</span><strong class="text-[#a62837]"><?php echo e($morosos); ?></strong><a class="font-bold" href="<?php echo e(route('admin.morosidad')); ?>">Revisar morosidad <span aria-hidden="true">→</span></a></article>
    <article class="stat-card"><span class="font-semibold text-[#716c77]">Préstamos activos</span><strong><?php echo e($prestamosActivos); ?></strong><a class="font-bold" href="<?php echo e(route('admin.prestamos.index')); ?>">Gestionar préstamos <span aria-hidden="true">→</span></a></article>
</div>
<section class="panel"><h2 class="font-display font-bold text-[#35234f]">Préstamos por mes</h2>
    <?php if($prestamosMes->isEmpty()): ?><p>Aún no hay préstamos registrados.</p><?php else: ?>
        <div class="table-wrap"><table><thead><tr><th>Mes</th><th>Préstamos</th></tr></thead><tbody>
        <?php $__currentLoopData = $prestamosMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($mes->mes); ?></td><td><?php echo e($mes->total); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody></table></div>
    <?php endif; ?>
</section>
<div class="grid-two">
    <section class="panel"><h2 class="font-display font-bold text-[#35234f]">Libros más prestados</h2>
        <?php $__empty_1 = true; $__currentLoopData = $librosMasPrestados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><p><?php echo e($libro->titulo); ?> <strong><?php echo e($libro->total); ?></strong></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p>Aún no hay préstamos registrados.</p><?php endif; ?>
    </section>
    <section class="panel"><h2 class="font-display font-bold text-[#35234f]">Socios por comuna</h2>
        <?php $__empty_1 = true; $__currentLoopData = $comunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><p><?php echo e($comuna->comuna); ?> <strong><?php echo e($comuna->total); ?></strong></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p>Sin información todavía.</p><?php endif; ?>
        <h3>Por ocupación</h3>
        <?php $__empty_1 = true; $__currentLoopData = $ocupaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ocupacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><p><?php echo e($ocupacion->ocupacion); ?> <strong><?php echo e($ocupacion->total); ?></strong></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p>Sin información todavía.</p><?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>