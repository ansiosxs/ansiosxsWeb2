
<?php $__env->startSection('title', $libro->titulo); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Ficha de libro</p><h1><?php echo e($libro->titulo); ?></h1><p class="muted"><?php echo e($libro->autor); ?></p></div><a class="button button-secondary" href="<?php echo e(route('admin.libros.edit', $libro)); ?>">Editar</a></div>
<section class="panel"><p><strong>Ubicación:</strong> <?php echo e($libro->mueble?->nombre ?? 'Sin asignar'); ?></p><p><strong>Ejemplares:</strong> <?php echo e($libro->ejemplares_count); ?> en total, <?php echo e($libro->disponibles_count); ?> disponibles.</p><p><strong>ISBN:</strong> <?php echo e($libro->isbn ?? 'No informado'); ?> · <strong>Editorial:</strong> <?php echo e($libro->editorial ?? 'No informada'); ?></p>
<a class="button" href="<?php echo e(route('admin.libros.ejemplares.index', $libro)); ?>">Administrar ejemplares</a>
<form class="inline-form danger-form" method="post" action="<?php echo e(route('admin.libros.destroy', $libro)); ?>" onsubmit="return confirm('¿Dar de baja este libro y sus ejemplares?')"><?php echo csrf_field(); ?> <?php echo method_field('delete'); ?><button class="button button-danger">Dar de baja libro</button></form></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/libros/show.blade.php ENDPATH**/ ?>