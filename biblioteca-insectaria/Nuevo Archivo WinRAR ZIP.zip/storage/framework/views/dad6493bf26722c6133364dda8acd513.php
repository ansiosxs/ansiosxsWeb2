
<?php $__env->startSection('title', 'Libros'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-heading"><div><p class="eyebrow">Catálogo</p><h1>Libros</h1></div><a class="button" href="<?php echo e(route('admin.libros.create')); ?>">Agregar libro</a></div>
<form class="search-form" method="get"><label for="q">Buscar por título, autor o código de barras</label><div class="inline-form"><input id="q" name="q" value="<?php echo e($q); ?>" type="search"><button class="button">Buscar</button></div></form>
<div class="table-wrap"><table><thead><tr><th>Libro</th><th>Ubicación</th><th>Ejemplares</th><th>Disponibles</th><th></th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr><td><strong><?php echo e($libro->titulo); ?></strong><br><span class="muted"><?php echo e($libro->autor); ?></span></td><td><?php echo e($libro->mueble?->nombre ?? 'Sin asignar'); ?></td><td><?php echo e($libro->ejemplares_count); ?></td><td><?php echo e($libro->disponibles_count); ?></td><td class="actions"><a href="<?php echo e(route('admin.libros.show', $libro)); ?>">Ficha</a><a href="<?php echo e(route('admin.libros.edit', $libro)); ?>">Editar</a></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5">No hay libros para mostrar.</td></tr><?php endif; ?>
</tbody></table></div>
<?php echo e($libros->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Seba\Documents\Nueva carpeta (9)\biblioteca-insectaria\resources\views/admin/libros/index.blade.php ENDPATH**/ ?>