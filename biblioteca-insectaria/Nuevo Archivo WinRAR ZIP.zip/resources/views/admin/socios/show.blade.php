@extends('layouts.admin')
@section('title', 'Ficha de socio')
@section('content')
<div class="page-heading"><div><p class="eyebrow">Ficha de socio</p><h1>{{ $socio->nombres }} {{ $socio->apellidos }}</h1></div><a class="button button-secondary" href="{{ route('admin.socios.edit', $socio) }}">Editar datos</a></div>
<section class="panel">
    <p><strong>RUN:</strong> {{ $socio->run }}</p><p><strong>Teléfono:</strong> {{ $socio->telefono }}</p><p><strong>Correo:</strong> {{ $socio->email ?? 'No informado' }}</p>
    <p><strong>Comuna:</strong> {{ $socio->comuna }} · <strong>Ocupación:</strong> {{ $socio->ocupacion ?? 'No informada' }}</p>
    <p><strong>Membresía hasta:</strong> {{ $socio->vigente_hasta->format('d/m/Y') }} · <strong>Estado:</strong> {{ $socio->activo ? ($socio->vigente_hasta->lt(today()) ? 'Vencida' : 'Vigente') : 'Inactivo' }}</p>
    <form method="post" action="{{ route('admin.socios.renovar', $socio) }}">@csrf<button class="button" type="submit">Renovar membresía por un año</button></form>
</section>
<section class="panel"><h2>Historial de préstamos</h2><div class="table-wrap"><table><thead><tr><th>Libro</th><th>Préstamo</th><th>Vencimiento</th><th>Devolución</th><th>Estado</th></tr></thead><tbody>
@forelse ($socio->prestamos as $prestamo)<tr><td>{{ $prestamo->ejemplar->libro->titulo }}</td><td>{{ $prestamo->fecha_prestamo->format('d/m/Y') }}</td><td>{{ $prestamo->fecha_vencimiento->format('d/m/Y') }}</td><td>{{ $prestamo->fecha_devolucion?->format('d/m/Y') ?? '—' }}</td><td>{{ ucfirst($prestamo->estado) }}</td></tr>
@empty<tr><td colspan="5">Sin préstamos registrados.</td></tr>@endforelse
</tbody></table></div></section>
@endsection
