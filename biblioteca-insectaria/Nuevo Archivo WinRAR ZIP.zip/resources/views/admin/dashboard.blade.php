@extends('layouts.admin')
@section('title', 'Resumen')
@section('content')
<div class="page-heading"><div><p class="eyebrow">Panel de gestión</p><h2 class="font-display text-2xl font-bold text-[#35234f] sm:text-3xl">Resumen de la biblioteca</h2><p class="muted mb-0">Estado actual y accesos rápidos para el equipo.</p></div></div>
<div class="stats-grid">
    <article class="stat-card"><span class="font-semibold text-[#716c77]">Socios con membresía vigente</span><strong>{{ $sociosActivos }}</strong><span class="text-sm text-[#716c77]">Membresías activas</span></article>
    <article class="stat-card"><span class="font-semibold text-[#716c77]">Préstamos vencidos</span><strong class="text-[#a62837]">{{ $morosos }}</strong><a class="font-bold" href="{{ route('admin.morosidad') }}">Revisar morosidad <span aria-hidden="true">→</span></a></article>
    <article class="stat-card"><span class="font-semibold text-[#716c77]">Préstamos activos</span><strong>{{ $prestamosActivos }}</strong><a class="font-bold" href="{{ route('admin.prestamos.index') }}">Gestionar préstamos <span aria-hidden="true">→</span></a></article>
</div>
<section class="panel"><h2 class="font-display font-bold text-[#35234f]">Préstamos por mes</h2>
    @if ($prestamosMes->isEmpty())<p>Aún no hay préstamos registrados.</p>@else
        <div class="table-wrap"><table><thead><tr><th>Mes</th><th>Préstamos</th></tr></thead><tbody>
        @foreach ($prestamosMes as $mes)<tr><td>{{ $mes->mes }}</td><td>{{ $mes->total }}</td></tr>@endforeach
        </tbody></table></div>
    @endif
</section>
<div class="grid-two">
    <section class="panel"><h2 class="font-display font-bold text-[#35234f]">Libros más prestados</h2>
        @forelse ($librosMasPrestados as $libro)<p>{{ $libro->titulo }} <strong>{{ $libro->total }}</strong></p>@empty<p>Aún no hay préstamos registrados.</p>@endforelse
    </section>
    <section class="panel"><h2 class="font-display font-bold text-[#35234f]">Socios por comuna</h2>
        @forelse ($comunas as $comuna)<p>{{ $comuna->comuna }} <strong>{{ $comuna->total }}</strong></p>@empty<p>Sin información todavía.</p>@endforelse
        <h3>Por ocupación</h3>
        @forelse ($ocupaciones as $ocupacion)<p>{{ $ocupacion->ocupacion }} <strong>{{ $ocupacion->total }}</strong></p>@empty<p>Sin información todavía.</p>@endforelse
    </section>
</div>
@endsection
