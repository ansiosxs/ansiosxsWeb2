@extends('layouts.admin')
@section('title', 'Préstamos')
@section('content')
<div class="page-heading"><div><p class="eyebrow">Circulación</p><h1>Préstamos y devoluciones</h1></div><a href="{{ route('admin.morosidad') }}">Ver morosidad</a></div>
<div class="grid-two">
    <section class="panel"><h2>Registrar préstamo</h2><p>Escanea el ejemplar, selecciona al socio y confirma.</p>
        <form class="form-stack" method="post" action="{{ route('admin.prestamos.store') }}" data-resiliente="prestamo">
            @csrf
            <label>Código del ejemplar<input name="codigo_barras" value="{{ old('codigo_barras') }}" required autofocus autocomplete="off">@error('codigo_barras')<span class="field-error">{{ $message }}</span>@enderror</label>
            <label>Socio<select name="socio_id" required><option value="">Selecciona un socio</option>@foreach ($socios as $socio)<option value="{{ $socio->id }}" @selected(old('socio_id') == $socio->id)>{{ $socio->apellidos }}, {{ $socio->nombres }} — {{ $socio->run }}</option>@endforeach</select>@error('socio_id')<span class="field-error">{{ $message }}</span>@enderror</label>
            <input type="hidden" name="operacion_uuid" value="{{ $operacionUuid }}">
            <button class="button" type="submit">Confirmar préstamo</button>
            <div class="resilience-notice" hidden role="alert"></div>
        </form>
    </section>
    <section class="panel"><h2>Registrar devolución</h2><p>Escanea el código del ejemplar para devolverlo.</p>
        <form class="form-stack" method="post" action="{{ route('admin.prestamos.devolver') }}" data-resiliente="devolucion">
            @csrf
            <label>Código del ejemplar<input name="codigo_barras" required autocomplete="off">@error('codigo_barras')<span class="field-error">{{ $message }}</span>@enderror</label>
            <button class="button button-secondary" type="submit">Registrar devolución</button>
            <div class="resilience-notice" hidden role="alert"></div>
        </form>
    </section>
</div>
<section class="panel"><h2>Préstamos activos</h2><div class="table-wrap"><table><thead><tr><th>Libro y código</th><th>Socio</th><th>Fecha de salida</th><th>Vencimiento</th><th>Estado</th></tr></thead><tbody>
@forelse ($prestamos as $prestamo)<tr><td>{{ $prestamo->ejemplar->libro->titulo }}<br><span class="muted">{{ $prestamo->ejemplar->codigo_barras }}</span></td><td>{{ $prestamo->socio->nombres }} {{ $prestamo->socio->apellidos }}<br><span class="muted">{{ $prestamo->socio->telefono }}</span></td><td>{{ $prestamo->fecha_prestamo->format('d/m/Y') }}</td><td>{{ $prestamo->fecha_vencimiento->format('d/m/Y') }}</td><td>{{ $prestamo->fecha_vencimiento->lt(today()) ? 'Vencido' : 'Activo' }}</td></tr>
@empty<tr><td colspan="5">No hay préstamos activos.</td></tr>@endforelse
</tbody></table></div>{{ $prestamos->links() }}</section>
<section class="panel"><h2>Contactar por teléfono</h2><p>Préstamos que vencen pronto y cuyos socios no tienen correo registrado.</p>
@forelse ($contactar as $prestamo)<p>{{ $prestamo->socio->nombres }} {{ $prestamo->socio->apellidos }} · {{ $prestamo->socio->telefono }} · {{ $prestamo->ejemplar->libro->titulo }}</p>@empty<p>No hay contactos pendientes.</p>@endforelse
</section>
@endsection
